import numpy as np
from sentence_transformers import SentenceTransformer

model = SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2')

def embed_texts(texts):
    emb = model.encode(texts, convert_to_numpy=True, show_progress_bar=False)
    # collapse norms to shape (n_chunks,)
    norms = np.linalg.norm(emb, axis=1)
    return emb, norms

def rank_sections(persona: str, jtbd: str, sections: list, top_k: int = 5):
    # encode persona and JTBD
    persona_emb = model.encode(persona, convert_to_numpy=True)
    jtbd_emb    = model.encode(jtbd,    convert_to_numpy=True)
    p_norm = np.linalg.norm(persona_emb)
    t_norm = np.linalg.norm(jtbd_emb)

    scored = []
    for s in sections:
        texts = [c['text'] for c in s['chunks']]
        if not texts:
            continue

        emb, norms = embed_texts(texts)  # emb: (n_chunks, dim), norms: (n_chunks,)
        # compute cosine sims
        sim_p = (emb @ persona_emb) / (norms * p_norm)  # shape (n_chunks,)
        sim_j = (emb @ jtbd_emb)    / (norms * t_norm)  # shape (n_chunks,)
        weighted = 0.7 * sim_j + 0.3 * sim_p            # shape (n_chunks,)

        idx = int(np.argmax(weighted))
        best_score = weighted[idx].item() if hasattr(weighted[idx], 'item') else float(weighted[idx])

        s['score']      = best_score
        s['best_chunk'] = s['chunks'][idx]
        scored.append(s)

    # pick top_k
    top = sorted(scored, key=lambda x: x['score'], reverse=True)[:top_k]

    extracted = []
    refined   = []
    for rank, s in enumerate(top, 1):
        extracted.append({
            "document":       s['document'],
            "section_title":  s['section_title'],
            "importance_rank": rank,
            "page_number":    s['start_page']
        })
        b = s['best_chunk']
        refined.append({
            "document":     s['document'],
            "refined_text": b['text'],
            "page_number":  b['page']
        })

    return extracted, refined
